//#include"cbnm_22mcce24.h"
#include<stdio.h>
#include<stdlib.h>
#include<malloc.h>
#include<string.h>
#include<math.h>


void createAugmentedMatrix(float (*)(float), float [], float (*)(float));
void printMatrix(double (*)(double));
void gaussianElimination(float (*)(float));
void backSubstitution(float (*)(float), float []);

double f(double );
double g(double );
double length_of_curve(double , double , double (*)(double), double );
double area_under_curve(double , double , double (*)(double), double );
double area_between_curves(double , double , double (*)(double), double (*)(double), double );
double simpsons_rule(double , double , double (*)(double), int );

float func(float );
void regula_falsi(float x1,float x2,int n);

float function(float );
void bisection(float ,float,int);

void jacobi(float (*)(float), float [], float [], int );

double f(double );
double df(double );
void newtonRaphson(double ); 

float func(float );
float findX(float ,float );
void secent(int ,int ,int );

double piecewise_linear(double , double , double , double , double , double , double );
double vandermonde(double , double *, int );
double lagrange(double , double *, double *, int );



void luDecomposition(double (*)(double), double (*)(double), double (*)(double));
void forwardSubstitution(double (*)(double), double [], double []);
void backwardSubstitution(double (*)(double), double [], double []); 


void vandermonde_new(double x[], double y[], int );
double polynomial(double [], double , int );