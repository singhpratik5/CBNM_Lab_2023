#include<stdio.h>
#include<stdlib.h>
//x1 , x2 -> initial values , n -> max iterations.

float bisection(float x)
{
    float y = 4*x*x*x*x*x - 3*x*x + 14*x -26;
    return y;
}

int main()
{
    // ask for x1,x2 -> [until f(x1).f(x2)!<0]
    float x,x1,x2;

    
    while(bisection(x1)*bisection(x2)>=0)
    {
        printf(" Enter x1 & x2\n");
        scanf("%f" "%f" ,&x1, &x2);
    }
    printf("root is between %f & %f\n",x1,x2);
    int i = 1;
    int n;
    printf("Enter the max iteration\n");
    scanf("%d",&n);
    while(i<=n)
    {
        float x3;
        x3 = (x1 + x2)/2;
        if(bisection(x3)*bisection(x1)<0)
        {
            x2 = x3;
        }
        else if(bisection(x3)*bisection(x2)<0)
        {
            x1 = x3;
        }
        printf("iteration = %d and root = %f\n",i,x3);
        i++;
    }
    exit(0);
}

