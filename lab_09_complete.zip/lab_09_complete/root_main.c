#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "cbnm_22mcce24.h"



int main(void)
{
    double ans;
    
    bisection(1.0, 10.0,50);  
    exit(0);
}