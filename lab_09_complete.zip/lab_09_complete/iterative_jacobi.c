#include<stdio.h>

#define N 5 // Number of equations

void jacobi(float a[N][N], float b[N], float x[N], int n) {
    float x_new[N];
    for (int i = 0; i < n; i++) {
        x_new[i] = x[i];
    }

    for (int k = 0; k < 10; k++) { // Number of iterations
        for (int i = 0; i < n; i++) {
            float sum = 0;
            for (int j = 0; j < n; j++) {
                if (j != i) {
                    sum += a[i][j] * x[j];
                }
            }
            x_new[i] = (b[i] - sum) / a[i][i];
        }

        for (int i = 0; i < n; i++) {
            x[i] = x_new[i];
        }
    }
}
/*

int main() {
    float a[N][N] = {{8,1,8,3,0}, {3,12,6,1,-2}, {2,8,17,5,-3},{7,-1,-2,-13,6},{3,-3,8,2,-20}}; // Coefficient matrix
    float b[N] = {37,15,56,-3,-15}; // Right-hand side vector
    float x[N] = {0, 0, 0,0,0}; // Initial solution vector

    jacobi(a, b, x, N);

    printf("Solution:\n");
    for (int i = 0; i < N; i++) {
        printf("x[%d] = %f\n", i, x[i]);
    }

    return 0;
}
*/